<button 
	class="btn btn-success" 
	type="button" 
	id="btnNuevo" 
	data-toggle="modal" 
	data-target="#modalArticulos" 
	data-keyboard="false" 
	data-backdrop="static">
	<i class="fa fa-plus"></i> Nuevo Bulto
</button>


<!-- Modal -->
<div class="modal fade" id="modalArticulos" tabindex="-1" role="dialog" aria-labelledby="modalArticulosLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="modalArticulosLabel">Ingreso de Artículos</h4>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label>Escanear Código de Barras</label>
					<div class="input-group">
						<div class="input-group-addon"><i class="fa fa-barcode"></i></div>
						<input type="text" class="form-control producto" name="codigoEscaneado" id="codigoEscaneado" autocomplete="off" onchange="buscarArticulo();">
					</div>
				</div>
				<div>
					<table class="table table-striped" id="tablaAgregarArticulos">
						<thead>	
							<tr>
								<th>Producto</th>
								<th>Cantidad</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
						
						</tbody>
					</table>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal" id="btnCerrarModal">Cerrar</button>
				<button type="button" class="btn btn-primary" id="btnAgregar" onclick="agregar();">Agregar</button>
			</div>
		</div>
	</div>
</div>


<script>
	$('#modalBultos').on('shown.bs.modal', function () {
    $('#codigoEscaneado').focus();
});



</script>


<div class="barcode">
	<label for="">HOLA</label>
    <p>{{$product}}</p>
  
    
  
</div>









































H1>Dynamsoft PHP Barcode Reader</H1>
<form action="dbr.php" method="post" enctype="multipart/form-data">
    Select barcode image:
    <input type="file" name="readBarcode" id="readBarcode" accept="image/*"><br>
    <input type="submit" value="Read Barcode" name="submit">
</form>
<div id="tiff"></div>
<div id='image'></div>
<script>
      function reset() {
        $("#image").empty();
        $("#tiff").empty();
      }
			var input = document.querySelector('input[type=file]');
			input.onchange = function() {
        reset();
				var file = input.files[0];
				var fileReader = new FileReader();
        // get file extension
        var extension = file.name.split('.').pop().toLowerCase();
        var isTiff = false;
        if (extension == "tif" || extension == "tiff") {
          isTiff = true;
        }
				fileReader.onload = function(e) {
          if (isTiff) {
            console.debug("Parsing TIFF image...");
            //initialize with 100MB for large files
            Tiff.initialize({
              TOTAL_MEMORY: 100000000
            });
            var tiff = new Tiff({
              buffer: e.target.result
            });
            var tiffCanvas = tiff.toCanvas();
            $(tiffCanvas).css({
              "max-width": "800px",
              "width": "100%",
              "height": "auto",
              "display": "block",
              "padding-top": "10px"
            }).addClass("TiffPreview");
            $("#tiff").append(tiffCanvas);
          }
          else {
            var dataURL = e.target.result, img = new Image();
            img.src = dataURL;
            $("#image").append(img);
          }
				}
        if (isTiff) {
            fileReader.readAsArrayBuffer(file);
        }
        else
				    fileReader.readAsDataURL(file);
			}
</script>